#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void ktSoNguyen(){
	fflush(stdin);
	printf("++-------------------------------------------------------++\n");
	printf("|             Chuong trinh kiem tra so nguyen             |\n");
	printf("++-------------------------------------------------------++\n\n\n");
	int x, i=0, result=0;
	printf("Nhap vao so nguyen x: ");
	if(scanf("%d", &x) == 1){
        printf("So %d la so nguyen\n",x);
	    if(x<2){
			result++;
		}
		for(i=2; i<x;i++){
			if(x%i==0){
				result++;
			}
		}
		if(result==0){
			printf("So %d la so nguyen to\n", x);
		}else{
			printf("So %d khong phai la so nguyen to\n",x);
		}
		if(x<1){
			printf("So %d khong phai la so chinh phuong\n",x);
		}
		for(i=1;i<=x;i++){
			if(i*i==x){
				printf("So %d la so chinh phuong\n",x);
				break;
			}
			if(i==x){
				printf("So %d khong phai la so chinh phuong\n",x);
				break;
			}
		}
    }
	else{
        printf("Khong phai la so nguyen.\n");
    }
}
void timUCLNvaBCNN(){
	fflush(stdin); 
	printf("++-------------------------------------------------------++\n");
	printf("| Chuong trinh tim uoc so chung va boi so chung cua 2 so  |\n");
	printf("++-------------------------------------------------------++\n\n\n");
	
	int x,y, UCLN, BCNN, yTam, xTam;
	
	do{
		fflush(stdin); 
		printf("Nhap vao so nguyen duong x: ");
	}while(scanf("%d",&x)!=1 || x<0);
	do{
		fflush(stdin); 
		printf("Nhap vao so nguyen duong y: ");
	}while(scanf("%d",&y)!=1 || y<0);
	xTam = x;
	yTam = y;
	if(x==0 || y==0){
		UCLN = x+y;
	}
	else{
		while(x!=y){
			if(x>y){
				x = x - y;
			}else{
				y = y - x;
			}
		}
	}
	if(x==y){
		UCLN = x;
	}
	if(x==0 && y==0){
		printf("2 so x va y khong co uoc so chung lon nhat\n",UCLN);
		printf("2 so x va y khong co boi so chung nho nhat\n",UCLN);
	}
	else{
		printf("Uoc chung lon nhat cua 2 so x va y la: %d\n",UCLN);
		if(xTam != 0 || yTam !=0)
			BCNN = xTam*yTam/UCLN;
		else
			BCNN = 0;
		printf("Boi chung nho nhat cua 2 so x va y la: %d", BCNN);
			
	}
	
	
}
void tinhTienKaraoke(){
	fflush(stdin); 
	printf("++-------------------------------------------------------++\n");
	printf("|             Chuong trinh tinh tien Karaoke              |\n");
	printf("++-------------------------------------------------------++\n\n\n");
	int start=100,end=100;
	printf("!!!!! Quan Karaoke hoat dong tu 12h den 23h !!!!!\n");
	
	do{
		fflush(stdin);
		printf("Nhap vao gio bat dau: ");
	}while(scanf("%d",&start)!=1 || start<12 || start>23);
	
	do{
		
		if(end < start){
			printf("\n!!!!! THOI GIAN KET THUC KHONG THE NHO HON THOI GIAN BAT DAU !!!!!\n");
		}
		if(end > 23){
				printf("\n!!!!! THOI GIAN KET THUC < 24 !!!!!\n");
		}
		fflush(stdin);
		printf("Nhap vao gio ket thuc: ");
	}while(scanf("%d",&end)!=1 || end<12 || end>23 || end<start);
	
	int thoiGian = end - start, tien;
	if(thoiGian <=3){
		tien = thoiGian * 150000;
	}
	else if(thoiGian > 3){
		tien = ((thoiGian - 3) * 150000 * 0.7) + 450000; //((tong thoi gian - 3 gio dau) * 150.000vnd * 0.7(-30%)) + tong tien 3 gio dau (450.000vnd)
	}
	if(start >= 14 && start<=17){
		tien = tien * 0.9;
	}
	printf("So tien can thanh toan la: %d VND", tien);
}
void tinhTienDien(){
	fflush(stdin); 
	printf("++-------------------------------------------------------++\n");
	printf("|               Chuong trinh tinh tien dien               |\n");
	printf("++-------------------------------------------------------++\n\n\n");
	int dien,tien;

	do{
		fflush(stdin);
		printf("Nhap vao so (kwh) dien da su dung: ");
	}while(scanf("%d",&dien)!=1 || dien<0);
	
		/*
		0 -> 50 = 83.900
		51 -> 100 = 86.700
		101 -> 200 = 201.400
		201 -> 300 = 253.600
		301 -> 400 = 283.400
		*/

		 if(dien <= 50){
			tien = dien * 1678;
		}
		else if(dien <= 100){
			tien = 83900 + ((dien-50)*1734);
		}
		else if(dien <= 200){
			tien = 83900 + 86700 + ((dien-100) * 2014);
		}
		else if(dien <= 300){
			tien = 83900 + 86700 + 201400 + ((dien-200) * 2536);
		}
		else if(dien <= 400){
			tien = 83900 + 86700 + 201400 + 253600 + ((dien-300) * 2834);
		}
		else if(dien > 400){
			tien = 83900 + 86700 + 201400 + 253600 + 283400 + ((dien-400) * 2927);
		}
	printf("Tien dien ban phai tra la: %d VND", tien);
}
void doiTien(){
	fflush(stdin); 
	printf("++-------------------------------------------------------++\n");
	printf("|                  Chuong trinh doi tien                  |\n");
	printf("++-------------------------------------------------------++\n\n\n");
	int tien=0,du=0;
	
	do{
		if(tien < 0){
			printf("So dien phai >= 1000\n");
		}
		printf("Nhap vao so tien ban can doi: ");
	}while(scanf("%d",&tien)!=1 || tien<1000);
	
	printf("Ban doi ra duoc:\n");
	if(tien>=500000){
		du = tien%500000;
		tien = tien - du;
		if(tien/500000!=0)
			printf("%d to 500.000 VND\n",tien/500000);
		tien = du;
	}
	if(tien <500000){
		du = tien%200000;
		tien = tien - du;
		if(tien/200000!=0)
			printf("%d to 200.000 VND\n",tien/200000);
		tien = du;
	}
	if(tien <200000){
		du = tien%100000;
		tien = tien - du;
		if(tien/100000!=0)
			printf("%d to 100.000 VND\n",tien/100000);
		tien = du;
	}
	if(tien <100000){
		du = tien%50000;
		tien = tien - du;
		if(tien/50000!=0)
			printf("%d to 50.000 VND\n",tien/50000);
		tien = du;
	}
	if(tien <50000){
		du = tien%20000;
		tien = tien - du;
		if(tien/20000!=0)
			printf("%d to 20.000 VND\n",tien/20000);
		tien = du;
	}
	if(tien <20000){
		du = tien%10000;
		tien = tien - du;
		if(tien/10000!=0)
			printf("%d to 10.000 VND\n",tien/10000);
		tien = du;
	}
	if(tien <10000){
		du = tien%5000;
		tien = tien - du;
		if(tien/5000!=0)
			printf("%d to 5.000 VND\n",tien/5000);
		tien = du;
	}
	if(tien <5000){
		du = tien%2000;
		tien = tien - du;
		if(tien/2000!=0)
			printf("%d to 2.000 VND\n",tien/2000);
		tien = du;
	}
	if(tien <2000){
		du = tien%1000;
		tien = tien - du;
		if(tien/1000!=0)
			printf("%d to 1.000 VND\n",tien/1000);
		tien = du;
	}
}
int main(int argc, char *argv[]) {
	menu:
	fflush(stdin); 
	system("cls");
	int menu=-1;
	printf("+++========================================================+++\n");
	printf("|        BAI ASSIGNMENT MON COM108 - LAP TRINH CO BAN        |\n");
	printf("|              Nguoi thuc hien: NGUYEN NGOC HUY              |\n");
	printf("|                       MSSV: PS14009                        |\n");
	printf("+++========================================================+++\n\n\n");
	
	printf("---------------------------[ MENU ]---------------------------\n");
	printf("| <1>   KIEM TRA SO NGUYEN                                   |\n");
	printf("| <2>   TIM UOC SO CHUNG VA BOI SO CHUNG CUA 2 SO            |\n");
	printf("| <3>   TINH TIEN CHO QUAN KARAOKE                           |\n");
	printf("| <4>   TINH TIEN DIEN                                       |\n");
	printf("| <5>   DOI TIEN                                             |\n");
	printf("| <6>   TINH LAI XUAT NGAN HANG VAY TRA GOP                  |\n");
	printf("| <7>   VAY TIEN MUA XE                                      |\n");
	printf("| <8>   SAP XEP THONG TIN SINH VIEN                          |\n");
	printf("| <9>   XAY DUNG GAME FPOLY-LOTT (2/15)                      |\n");
	printf("| <10>  TINH PHAN SO                                         |\n");
	printf("| <0>   THOAT KHOI CHUONG TRINH                              |\n");
	printf("--------------------------------------------------------------\n\n");
	
	do{
	printf("Moi ban chon chuong trinh (0,1,2,...): ");
	scanf("%d",&menu);
	}while(menu<0 || menu>10);
	
	switch(menu){
		case 0: exit(0);
		case 1:{
			case1:
			system("cls");
			ktSoNguyen();
			printf("\n\n\n++-------------------------------------------------------++\n");
			printf("| Ban co muon tiep tuc ?                                  |\n");
			printf("| Nhan 1 de tiep tuc.                                     |\n");
			printf("| Nhan 2 de quay ve menu.                                 |\n");
			printf("| Nhan 0 de thoat chuong trinh.                           |\n");
			printf("++-------------------------------------------------------++\n");
			int chon;
			do{
				printf("Ban chon (0,1,2): ");
				scanf("%d",&chon);
			}while(chon<0 || chon>2);
			
			switch(chon){
				case 0: exit(0);
				case 1:{
					system("cls");
					goto case1;
					break;
				} 
				case 2:{
					system("cls");
					goto menu;
					break;
				} 
			}
			break;
		}
		case 2:{
			case2:
			system("cls");
			timUCLNvaBCNN();
			printf("\n\n\n++-------------------------------------------------------++\n");
			printf("| Ban co muon tiep tuc ?                                  |\n");
			printf("| Nhan 1 de tiep tuc.                                     |\n");
			printf("| Nhan 2 de quay ve menu.                                 |\n");
			printf("| Nhan 0 de thoat chuong trinh.                           |\n");
			printf("++-------------------------------------------------------++\n");
			int chon;
			do{
				printf("Ban chon (0,1,2): ");
				scanf("%d",&chon);
			}while(chon<0 || chon>2);
			
			switch(chon){
				case 0: exit(0);
				case 1:{
					system("cls");
					goto case2;
					break;
				}
				case 2:{
					system("cls");
					goto menu;
					break;
				} 
			}
			break;
		}
		case 3:{
			case3:
			system("cls");
			tinhTienKaraoke();
			printf("\n\n\n++-------------------------------------------------------++\n");
			printf("| Ban co muon tiep tuc ?                                  |\n");
			printf("| Nhan 1 de tiep tuc.                                     |\n");
			printf("| Nhan 2 de quay ve menu.                                 |\n");
			printf("| Nhan 0 de thoat chuong trinh.                           |\n");
			printf("++-------------------------------------------------------++\n");
			int chon;
			do{
				printf("Ban chon (0,1,2): ");
				scanf("%d",&chon);
			}while(chon<0 || chon>2);
			
			switch(chon){
				case 0: exit(0);
				case 1:{
					system("cls");
					goto case3;
					break;
				}
				case 2:{
					system("cls");
					goto menu;
					break;
				} 
			}
			break;
		}
		case 4:{
			case4:
			system("cls");
			tinhTienDien();
			printf("\n\n\n++-------------------------------------------------------++\n");
			printf("| Ban co muon tiep tuc ?                                  |\n");
			printf("| Nhan 1 de tiep tuc.                                     |\n");
			printf("| Nhan 2 de quay ve menu.                                 |\n");
			printf("| Nhan 0 de thoat chuong trinh.                           |\n");
			printf("++-------------------------------------------------------++\n");
			int chon;
			do{
				printf("Ban chon (0,1,2): ");
				scanf("%d",&chon);
			}while(chon<0 || chon>2);
			
			switch(chon){
				case 0: exit(0);
				case 1:{
					system("cls");
					goto case4;
					break;
				}
				case 2:{
					system("cls");
					goto menu;
					break;
				} 
			}
			break;
		}
		case 5:{
			case5:
			system("cls");
			doiTien();
			printf("\n\n\n++-------------------------------------------------------++\n");
			printf("| Ban co muon tiep tuc ?                                  |\n");
			printf("| Nhan 1 de tiep tuc.                                     |\n");
			printf("| Nhan 2 de quay ve menu.                                 |\n");
			printf("| Nhan 0 de thoat chuong trinh.                           |\n");
			printf("++-------------------------------------------------------++\n");
			int chon;
			do{
				printf("Ban chon (0,1,2): ");
				scanf("%d",&chon);
			}while(chon<0 || chon>2);
			
			switch(chon){
				case 0: exit(0);
				case 1:{
					system("cls");
					goto case5;
					break;
				}
				case 2:{
					system("cls");
					goto menu;
					break;
				} 
			}
			break;
		}
		case 6:{
			printf("\n!!!!! Chuc nang dang duoc xay dung !!!!!!");
			getch();
			goto menu;
			break;
		}
		case 7:{
			printf("\n!!!!! Chuc nang dang duoc xay dung !!!!!!");
			getch();
			goto menu;
			break;
		}
		case 8:{
			printf("\n!!!!! Chuc nang dang duoc xay dung !!!!!!");
			getch();
			goto menu;
			break;
		}
		case 9:{
			printf("\n!!!!! Chuc nang dang duoc xay dung !!!!!!");
			getch();
			goto menu;
			break;
		}
		case 10:{
			printf("\n!!!!! Chuc nang dang duoc xay dung !!!!!!");
			getch();
			goto menu;
			break;
		}
		default:{
			printf("Da xay ra loi, moi ban thu lai !!!");
			break;
		}
	}
	return 0;
}



