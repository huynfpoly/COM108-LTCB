#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int timMax(int a, int b, int c){
	int max=a;
	
	if(max<b){
		max = b;
	}
	if(max<c){
		max = c;
	}
	
	return max;
}
int checkYear(int y){
	int result=0;
	if(y % 400 == 0){
		result = 1;
	}	
	if(y % 4 == 0 && y % 100 != 0){
		result = 1;
	}
	return result;
}
void swap(int *a, int *b){
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
}





int main(int argc, char *argv[]) {
	menu:
	fflush(stdin); 
	system("cls");
	int menu=-1;
	printf("+++========================================================+++\n");
	printf("|          BAI-4 LAB-5 MON COM108 - LAP TRINH CO BAN         |\n");
	printf("|              Nguoi thuc hien: NGUYEN NGOC HUY              |\n");
	printf("|                       MSSV: PS14009                        |\n");
	printf("+++========================================================+++\n\n\n");
	
	printf("---------------------------[ MENU ]---------------------------\n");
	printf("| <1>   SO SANH 3 SO NGUYEN                                  |\n");
	printf("| <2>   KIEM TRA NAM NHUAN                                   |\n");
	printf("| <3>   HOAN VI 2 SO                                         |\n");
	printf("--------------------------------------------------------------\n");
	printf("| <0>   THOAT KHOI CHUONG TRINH                              |\n");
	printf("--------------------------------------------------------------\n\n");
	
	do{
	printf("Moi ban chon chuong trinh (0,1,2,...): ");
	scanf("%d",&menu);
	}while(menu<0 || menu>3);
	
	switch(menu){
		case 0: exit(0);
		case 1:{
			case1:
			system("cls");
			fflush(stdin);
			printf("++-------------------------------------------------------++\n");
			printf("|             Chuong trinh so sanh 3 so nguyen             |\n");
			printf("++-------------------------------------------------------++\n\n\n");
			int a,b,c,max;
			printf("Nhap vao 3 so can so sanh: ");
			scanf("%d%d%d",&a,&b,&c);
			max = timMax(a,b,c);
			printf("So lon nhat la: %d", max);
			
			printf("\n\n\n++-------------------------------------------------------++\n");
			printf("| Ban co muon tiep tuc ?                                  |\n");
			printf("| Nhan 1 de tiep tuc.                                     |\n");
			printf("| Nhan 2 de quay ve menu.                                 |\n");
			printf("| Nhan 0 de thoat chuong trinh.                           |\n");
			printf("++-------------------------------------------------------++\n");
			int chon;
			do{
				printf("Ban chon (0,1,2): ");
				scanf("%d",&chon);
			}while(chon<0 || chon>2);
			
			switch(chon){
				case 0: exit(0);
				case 1:{
					system("cls");
					goto case1;
					break;
				} 
				case 2:{
					system("cls");
					goto menu;
					break;
				} 
			}
			break;
		}
		case 2:{
			case2:
			system("cls");
			fflush(stdin);
			printf("++-------------------------------------------------------++\n");
			printf("|             Chuong trinh kiem tra nam nhuan             |\n");
			printf("++-------------------------------------------------------++\n\n\n");
			int y;
			printf("Nhap vao nam can kiem tra: ");
			scanf("%d",&y);
			if(checkYear(y)){
				printf("Nam %d la nam nhuan.",y);
			}else{
				printf("Nam %d khong phai la nam nhuan.",y);
			}
			
			printf("\n\n\n++-------------------------------------------------------++\n");
			printf("| Ban co muon tiep tuc ?                                  |\n");
			printf("| Nhan 1 de tiep tuc.                                     |\n");
			printf("| Nhan 2 de quay ve menu.                                 |\n");
			printf("| Nhan 0 de thoat chuong trinh.                           |\n");
			printf("++-------------------------------------------------------++\n");
			int chon;
			do{
				printf("Ban chon (0,1,2): ");
				scanf("%d",&chon);
			}while(chon<0 || chon>2);
			
			switch(chon){
				case 0: exit(0);
				case 1:{
					system("cls");
					goto case2;
					break;
				}
				case 2:{
					system("cls");
					goto menu;
					break;
				} 
			}
			break;
		}
		case 3:{
			case3:
			system("cls");
			fflush(stdin);
			printf("++-------------------------------------------------------++\n");
			printf("|                Chuong trinh hoan vi 2 so                |\n");
			printf("++-------------------------------------------------------++\n\n\n");
			int a, b;
			printf("Nhap vao 2 so can hoan vi: ");
			scanf("%d%d", &a,&b);
			swap(&a,&b);
			printf("\n2 so sau khi hoan vi: %d %d",a,b);
			
			printf("\n\n\n++-------------------------------------------------------++\n");
			printf("| Ban co muon tiep tuc ?                                  |\n");
			printf("| Nhan 1 de tiep tuc.                                     |\n");
			printf("| Nhan 2 de quay ve menu.                                 |\n");
			printf("| Nhan 0 de thoat chuong trinh.                           |\n");
			printf("++-------------------------------------------------------++\n");
			int chon;
			do{
				printf("Ban chon (0,1,2): ");
				scanf("%d",&chon);
			}while(chon<0 || chon>2);
			
			switch(chon){
				case 0: exit(0);
				case 1:{
					system("cls");
					goto case3;
					break;
				}
				case 2:{
					system("cls");
					goto menu;
					break;
				} 
			}
			break;
		}
		default:{
			printf("Da xay ra loi, moi ban thu lai !!!");
			break;
		}
	}
	return 0;
}
