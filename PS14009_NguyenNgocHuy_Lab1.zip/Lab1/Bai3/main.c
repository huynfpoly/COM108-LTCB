#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	// N
	printf("*        *\n");
	printf("* *      *\n");
	printf("*   *    *\n");
	printf("*     *  *\n");
	printf("*      * *\n");
	printf("*        *\n");
	printf("\n");
	
	// G
	printf("   * * *  \n");
	printf(" *        \n");
	printf("*         \n");
	printf("*     * * \n");
	printf(" *       *\n");
	printf("   * * *  \n");
	printf("\n");
	
	// U
	printf("*        *\n");
	printf("*        *\n");
	printf("*        *\n");
	printf("*        *\n");
	printf(" *      * \n");
	printf("   * * *  \n");
	printf("\n");
	
	// Y
	printf("*        *\n");
	printf("  *    *  \n");
	printf("    **    \n");
	printf("    **     \n");
	printf("    **    \n");
	printf("    **    \n");
	printf("\n");
	
	// E
	printf("* * * * * \n");
	printf("*         \n");
	printf("* * *     \n");
	printf("*         \n");
	printf("*         \n");
	printf("* * * * * \n");
	printf("\n");
	
	// N
	printf("*        *\n");
	printf("* *      *\n");
	printf("*   *    *\n");
	printf("*     *  *\n");
	printf("*      * *\n");
	printf("*        *\n");
	printf("\n");
	
	
	
	
	// N
	printf("*        *\n");
	printf("* *      *\n");
	printf("*   *    *\n");
	printf("*     *  *\n");
	printf("*      * *\n");
	printf("*        *\n");
	printf("\n");
	
	// G
	printf("   * * *  \n");
	printf(" *        \n");
	printf("*         \n");
	printf("*     * * \n");
	printf(" *       *\n");
	printf("   * * *  \n");
	printf("\n");
	
	// O
	printf("   * * *  \n");
	printf(" *      *  \n");
	printf("*        *\n");
	printf("*        *\n");
	printf(" *      * \n");
	printf("   * * *  \n");
	printf("\n");
	
	// C
	printf("   * * * *\n");
	printf(" *        \n");
	printf("*         \n");
	printf("*         \n");
	printf(" *        \n");
	printf("   * * * *\n");
	printf("\n");
	
	
	
	// H
	printf("*        *\n");
	printf("*        *\n");
	printf("* * * * **\n");
	printf("*        *\n");
	printf("*        *\n");
	printf("*        *\n");
	printf("\n");
	

	// U
	printf("*        *\n");
	printf("*        *\n");
	printf("*        *\n");
	printf("*        *\n");
	printf(" *      * \n");
	printf("   * * *  \n");
	printf("\n");
	
	// Y
	printf("*        *\n");
	printf("  *    *  \n");
	printf("    **    \n");
	printf("    **     \n");
	printf("    **    \n");
	printf("    **    \n");
	printf("\n");
	
	
	return 0;
}
