#include <stdio.h>
#include <stdlib.h>
//Day la chuong trinh dau tien
int main(){
	/*
	Chuong trinh in ra thong tin
	- MSSV
	- Ho va ten
	- Tuoi
	- Trang thai
	*/
	printf("MSSV: PS14009\n");
	printf("Ho va Ten: Nguyen Ngoc Huy\n");
	printf("Tuoi: 18\n");
	printf("Da co nguoi yeu");
	return 0;
}
